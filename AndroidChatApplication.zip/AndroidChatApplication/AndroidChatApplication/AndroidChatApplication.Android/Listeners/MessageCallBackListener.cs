﻿using Com.Twilio.Chat;

namespace AndroidChatApplication.Droid.Listeners
{
    public class MessageCallBackListener<T> : CallbackListener<Message>
    {
        public override void OnSuccess(Message result)
        {

        }
    }
}